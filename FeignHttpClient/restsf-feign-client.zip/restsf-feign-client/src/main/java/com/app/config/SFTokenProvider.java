package com.app.config;

import org.springframework.stereotype.Component;

@Component
public class SFTokenProvider {

}
