package comappmy.comappmy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComAppMyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComAppMyApplication.class, args);
	}

}
